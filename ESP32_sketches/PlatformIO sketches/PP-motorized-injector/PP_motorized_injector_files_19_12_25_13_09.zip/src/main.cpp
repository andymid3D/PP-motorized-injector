#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_NeoPixel.h>
#include <Bounce2.h>
#include <SafeString.h>

#include "config.h"
#include "injector_fsm.h"
#include "SafetyManager.h"
#include "CanBusHandler.h"

// --- FSM Global Variables ---
fsm_inputs_t fsm_inputs;
fsm_outputs_t fsm_outputs;
fsm_state_t fsm_state;

// --- Hardware Objects ---
SafetyManager safety;
CanBusHandler motor;
Adafruit_NeoPixel ledsButtons(LED_COUNT_BUTTONS, PIN_LED_BUTTONS, NEO_GRB + NEO_KHZ800);
Adafruit_NeoPixel ledsRing(LED_COUNT_RING, PIN_LED_RING, NEO_GRB + NEO_KHZ800);

// --- Input Debouncers ---
Bounce2::Button btnSelect = Bounce2::Button();
Bounce2::Button btnUp = Bounce2::Button();
Bounce2::Button btnDown = Bounce2::Button();

// --- Global Flags & Timers ---
MachineFlags flags = {0, 0, 0}; 
unsigned long lastAutoCompress = 0;
unsigned long antiDripTimer = 0;
unsigned long lastDebugTime = 0;
bool tempErrorActive = false; 
int rawTempDebug = 0; 

// --- Parameters ---
float constantInjectionParams[] = {
    SPEED_PURGE, SPEED_FAST_MOVE, SPEED_COMPRESS_INIT, SPEED_COMPRESS_MIN,
    (float)TIME_ANTIDRIP_MAX, SPEED_PURGE, SPEED_RELEASE, DIST_RELEASE_MOULD
};

// --- Helper: Log ---
void logMessage(const char* msg) { Serial.println(msg); }

// --- Helper: Read Temp (Filtered) ---
int readThermocouple() {
    static int lastValidTemp = 20; 
    long sum = 0;
    const int samples = 10;
    for(int i=0; i<samples; i++) sum += analogRead(PIN_TEMP_ANALOG);
    float avgAdc = sum / (float)samples;
    float voltage = (avgAdc / 4095.0) * 3.3;
    float currentTemp = voltage / 0.01; 
    rawTempDebug = (int)currentTemp; 
    if (currentTemp < 5.0f) return lastValidTemp;
    static float smoothedTemp = 0;
    if (smoothedTemp == 0) smoothedTemp = currentTemp;
    smoothedTemp = (smoothedTemp * 0.95) + (currentTemp * 0.05);
    lastValidTemp = (int)smoothedTemp;
    return lastValidTemp;
}

// --- Helper: Velocity Ramp (Virtual Setpoint) ---
void rampVelocity(float targetVel, float accel) {
    static float virtualVelocity = 0.0f; 
    static unsigned long lastRampTime = 0;
    unsigned long now = millis();
    float dt = (now - lastRampTime) / 1000.0f;
    lastRampTime = now;
    
    // Reset if too much time passed (state change)
    if (dt > 0.1f) { dt = 0.0f; virtualVelocity = 0.0f; }
    
    float maxChange = accel * dt;
    if (virtualVelocity < targetVel) {
        virtualVelocity += maxChange;
        if (virtualVelocity > targetVel) virtualVelocity = targetVel;
    } else {
        virtualVelocity -= maxChange;
        if (virtualVelocity < targetVel) virtualVelocity = targetVel;
    }
    motor.setVelocity(virtualVelocity);
}

// --- Helper: State Names (Shortened for Display) ---
const char* getStateName(int state) {
    switch(state) {
        case ERROR_STATE: return "ERR";
        case INIT_HEATING: return "HEAT";
        case INIT_HOT_NOT_HOMED: return "WAIT_HM";
        case INIT_HOMING: return "HOMING";
        case REFILL: return "REFILL";
        case COMPRESSION: return "COMPRESS";
        case READY_TO_INJECT: return "READY";
        case PURGE_ZERO: return "PURGE";
        case ANTIDRIP: return "A-DRIP";
        case INJECT: return "INJECT";
        case HOLD_INJECTION: return "HOLD";
        case RELEASE: return "RELEASE";
        case CONFIRM_MOULD_REMOVAL: return "CONFIRM";
        default: return "???";
    }
}

// --- Helper: LEDs ---
void updateLeds() {
    uint32_t colSel = BLACK_RGB;
    uint32_t colUp = BLACK_RGB;
    uint32_t colDown = BLACK_RGB;
    uint32_t colRing = BLACK_RGB;
    switch (fsm_state.currentState) {
        case ERROR_STATE: if ((millis() / 500) % 2 == 0) { colSel = RED_RGB; colUp = RED_RGB; colDown = RED_RGB; colRing = RED_RGB; } break;
        case INIT_HEATING: colSel = RED_RGB; colUp = RED_RGB; colDown = RED_RGB; colRing = RED_RGB; break;
        case INIT_HOT_NOT_HOMED: colSel = YELLOW_RGB; colUp = YELLOW_RGB; colDown = YELLOW_RGB; colRing = YELLOW_RGB; break;
        case INIT_HOMING: colUp = YELLOW_RGB; colRing = YELLOW_RGB; break;
        case REFILL: colSel = GREEN_RGB; if (flags.endOfDay) { colUp = BLUE_RGB; colDown = BLUE_RGB; } else { colUp = BLACK_RGB; colDown = BLACK_RGB; } colRing = GREEN_RGB; break;
        case COMPRESSION: colSel = RED_RGB; colRing = RED_RGB; break;
        case READY_TO_INJECT: colSel = GREEN_RGB; colUp = BLACK_RGB; colDown = GREEN_RGB; colRing = GREEN_RGB; break; // Fixed: Down Green
        case PURGE_ZERO: colSel = GREEN_RGB; colUp = YELLOW_RGB; colDown = YELLOW_RGB; colRing = YELLOW_RGB; break;
        case ANTIDRIP: colSel = RED_RGB; colUp = GREEN_RGB; colDown = GREEN_RGB; colRing = RED_RGB; break;
        case INJECT: colSel = RED_RGB; colUp = GREEN_RGB; colDown = BLACK_RGB; colRing = RED_RGB; break;
        case HOLD_INJECTION: colSel = RED_RGB; colUp = GREEN_RGB; colDown = GREEN_RGB; colRing = RED_RGB; break;
        case RELEASE: colSel = GREEN_RGB; colUp = GREEN_RGB; colDown = GREEN_RGB; colRing = GREEN_RGB; break;
        case CONFIRM_MOULD_REMOVAL: colSel = GREEN_RGB; colUp = GREEN_RGB; colDown = GREEN_RGB; colRing = GREEN_RGB; break;
    }
    ledsButtons.setPixelColor(0, colSel); ledsButtons.setPixelColor(1, colUp); ledsButtons.setPixelColor(2, colDown); ledsButtons.show();
    for(int i=0; i<LED_COUNT_RING; i++) ledsRing.setPixelColor(i, colRing); ledsRing.show();
}

// --- Homing Sequence ---
bool runHomingSequence() {
    static int step = 0;
    static int lastStep = -1; 
    static unsigned long waitStart = 0;
    static unsigned long ignoreSafetyTimer = 0;
    if (step != lastStep) {
        switch(step) {
            case 0: logMessage("Home: Clear Err"); break;
            case 2: logMessage("Home: Calib"); break;
            case 5: logMessage("Home: Closed Loop"); break;
            case 6: logMessage("Home: Move Up"); break;
            case 7: logMessage("Home: Hit! Backoff"); break;
        }
        lastStep = step;
    }
    // Error Check (Ignore if expected hit)
    if (step >= 2 && motor.getAxisError() != 0) {
        bool expectedError = (step == 6 && safety.isTopEndstopHit());
        if (!expectedError && (millis() - ignoreSafetyTimer > 500)) {
            cSF(errBuf, 64); errBuf.print("Home Fail: 0x"); errBuf.print(motor.getAxisError(), HEX); logMessage(errBuf.c_str());
            step = 0; return false;
        }
    }
    switch(step) {
        case 0: safety.setContext(CTX_MOVING_FREE); motor.clearErrors(); waitStart = millis(); step++; break;
        case 1: if (millis() - waitStart > 500) step++; break;
        case 2: motor.setAxisState(7); waitStart = millis(); step++; break;
        case 3: if (motor.getAxisState() == 7) step++; if (millis() - waitStart > 1000) step++; break;
        case 4: if (motor.getAxisState() == 1) { step++; } break;
        case 5: if (motor.getAxisState() != 8) { motor.setAxisState(8); motor.setControllerMode(2, 1); ignoreSafetyTimer = millis(); } else { step++; } break;
        case 6: if (millis() - ignoreSafetyTimer < 250) return false; motor.setVelocity(-SPEED_HOMING_FAST); if (safety.isTopEndstopHit()) { motor.stop(); motor.clearErrors(); step++; } break;
        case 7: motor.setPosition(motor.getPosition() + DIST_HOME_BACKOFF); waitStart = millis(); step++; break;
        case 8: if (millis() - waitStart > 500) step++; break;
        case 9: motor.setVelocity(-SPEED_HOMING_SLOW); if (safety.isTopEndstopHit()) { motor.stop(); motor.clearErrors(); step++; } break;
        case 10: if (!flags.initialHomingDone) { motor.setPosition(0.0f); flags.initialHomingDone = true; } logMessage("Home: Done"); step = 0; lastStep = -1; return true; 
    }
    return false;
}

// --- Compression Cycle ---
bool runCompressionCycle() {
    safety.setContext(CTX_BLOCKED);
    motor.setAxisState(8);
    motor.setControllerMode(2, 1); 
    // Reduced Acceleration to prevent 0x40 Error
    rampVelocity(SPEED_COMPRESS_INIT, 1.0f); // Very gentle ramp
    
    // If torque limit hit (Plunger) OR Nozzle Block Ignored (Testing)
    if (motor.getTorque() > TORQUE_COMPRESSION_HOLD) { motor.stop(); return true; }
    return false;
}

// --- Pressure Filter ---
long getFilteredPressure() {
    static long pBuffer[9];
    static uint8_t pIdx = 0;
    long raw = safety.getPressure();
    if (raw == -1 || raw == 0) return pBuffer[(pIdx == 0 ? 8 : pIdx - 1)]; 
    pBuffer[pIdx] = raw; pIdx = (pIdx + 1) % 9;
    long sorted[9]; memcpy(sorted, pBuffer, sizeof(pBuffer));
    for(int i=0; i<9; i++) { for(int j=i+1; j<9; j++) { if(sorted[i] > sorted[j]) { long temp = sorted[i]; sorted[i] = sorted[j]; sorted[j] = temp; }}}
    return sorted[4]; 
}

// --- Debug Report (Formatted) ---
void printDebugReport() {
    char buf[128];
    // Format: [STATE] T:20 P:123456 | E:0 B:0 T:0 B:0 | CAN:OK Err:0x0 V:48.0 I:0.5 | P:10.0 V:5.0
    snprintf(buf, sizeof(buf), "[%-8s] T:%-3d P:%-7ld | E:%d B:%d T:%d B:%d | CAN:%s Err:0x%-2X V:%-4.1f I:%-4.1f | P:%-6.1f V:%-5.1f",
        getStateName(fsm_state.currentState),
        fsm_inputs.nozzleTemperature, getFilteredPressure(),
        safety.isEStopPressed(), safety.isBarrelOpen(), safety.isTopEndstopHit(), safety.isBottomEndstopHit(),
        motor.isAlive() ? "OK" : "DEAD", motor.getAxisError(),
        motor.getBusVoltage(), motor.getBusCurrent(),
        motor.getPosition(), motor.getVelocity()
    );
    Serial.println(buf);
}

void setup() {
    Serial.begin(115200); delay(1000); SafeString::setOutput(Serial); 
    safety.begin(); motor.begin(); pinMode(PIN_TEMP_ANALOG, INPUT);
    ledsButtons.begin(); ledsRing.begin(); ledsButtons.setBrightness(LED_BRIGHT_LOW); ledsRing.setBrightness(LED_BRIGHT_LOW);
    btnSelect.attach(PIN_BTN_SELECT, INPUT_PULLUP); btnUp.attach(PIN_BTN_UP, INPUT_PULLUP); btnDown.attach(PIN_BTN_DOWN, INPUT_PULLUP);
    btnSelect.interval(10); btnUp.interval(10); btnDown.interval(10);
    fsm_state.currentState = InjectorStates::INIT_HEATING;
}

void loop() {
    motor.loop(); safety.updateInputs(); fsm_inputs.nozzleTemperature = readThermocouple();
    
    // Request Vbus every 200ms (Faster update)
    static unsigned long lastVbusReq = 0;
    if (millis() - lastVbusReq > 200) { motor.requestVbusVoltage(); lastVbusReq = millis(); }

    // Temp Check
    static unsigned long lowTempStart = 0;
    if (fsm_state.currentState != INIT_HOMING) { 
        if (fsm_inputs.nozzleTemperature < TEMP_CRITICAL) {
             if (lowTempStart == 0) lowTempStart = millis();
             if (millis() - lowTempStart > 2000) { 
                 if (!tempErrorActive) { safety.triggerHalt(ERR_UNDER_TEMP); fsm_state.currentState = InjectorStates::ERROR_STATE; tempErrorActive = true; }
             }
        } else { lowTempStart = 0; if (fsm_inputs.nozzleTemperature > (TEMP_CRITICAL + 2)) { tempErrorActive = false; } }
    } else { lowTempStart = 0; }

    // Safety Check
    bool movingDown = motor.getVelocity() > 0.1f;
    if (!safety.check(motor.getVelocity(), movingDown)) { fsm_state.currentState = InjectorStates::ERROR_STATE; fsm_state.error = safety.getLastError(); }

    // Motor Error Check (Global)
    if (motor.getAxisError() != 0 && fsm_state.currentState != INIT_HOMING && fsm_state.currentState != ERROR_STATE) {
        logMessage("Motor Error Detected! Halting.");
        fsm_state.currentState = InjectorStates::ERROR_STATE;
    }

    switch (fsm_state.currentState) {
        case InjectorStates::ERROR_STATE:
            safety.enableMotorPower(false);
            // Auto-Clear Motor Errors if in Error State
            if (motor.getAxisError() != 0) motor.clearErrors();
            
            if (digitalRead(PIN_ESTOP) == LOW && digitalRead(PIN_ENDSTOP_BARREL) == LOW && fsm_inputs.nozzleTemperature >= (TEMP_CRITICAL + 2)) {
                 logMessage("Safety Restored."); safety.resetError(); fsm_state.error = 0; fsm_state.currentState = InjectorStates::INIT_HEATING;
            }
            break;
        case InjectorStates::INIT_HEATING: safety.enableMotorPower(false); if (fsm_inputs.nozzleTemperature >= TEMP_MIN_MOVE) fsm_state.currentState = InjectorStates::INIT_HOT_NOT_HOMED; break;
        case InjectorStates::INIT_HOT_NOT_HOMED: safety.enableMotorPower(true); btnUp.update(); if (btnUp.pressed()) fsm_state.currentState = InjectorStates::INIT_HOMING; break;
        case InjectorStates::INIT_HOMING: if (runHomingSequence()) { motor.setPosition(OFFSET_REFILL_GAP); fsm_state.currentState = InjectorStates::REFILL; } break;
        case InjectorStates::REFILL:
            safety.setContext(CTX_IDLE); btnSelect.update(); btnUp.update(); btnDown.update();
            if (btnUp.read() == LOW && btnDown.read() == LOW) { flags.endOfDay = !flags.endOfDay; delay(500); }
            if (btnSelect.pressed()) fsm_state.currentState = InjectorStates::COMPRESSION;
            break;
        case InjectorStates::COMPRESSION:
            btnSelect.update();
            // Manual Advance
            if (btnSelect.pressed()) { motor.stop(); fsm_state.currentState = InjectorStates::READY_TO_INJECT; lastAutoCompress = millis(); }
            if (runCompressionCycle()) { fsm_state.currentState = InjectorStates::READY_TO_INJECT; lastAutoCompress = millis(); }
            break;
        case InjectorStates::READY_TO_INJECT:
            safety.setContext(CTX_IDLE); btnSelect.update(); btnUp.update(); btnDown.update();
            if (millis() - lastAutoCompress > TIME_AUTO_COMPRESS) fsm_state.currentState = InjectorStates::COMPRESSION; 
            if (btnUp.pressed()) fsm_state.currentState = InjectorStates::REFILL;
            if (btnSelect.read() == LOW && btnDown.read() == LOW) fsm_state.currentState = InjectorStates::PURGE_ZERO;
            break;
        case InjectorStates::PURGE_ZERO:
            safety.setContext(CTX_PURGE); btnUp.update(); btnDown.update(); btnSelect.update(); motor.setControllerMode(2, 1); 
            if (btnUp.isPressed()) rampVelocity(-SPEED_PURGE, 1.0f);
            else if (btnDown.isPressed()) rampVelocity(SPEED_PURGE, 1.0f);
            else motor.stop();
            if (btnSelect.pressed()) { fsm_state.currentState = InjectorStates::ANTIDRIP; antiDripTimer = millis(); motor.setPosition(motor.getPosition() + DIST_ANTIDRIP_REV); }
            break;
        case InjectorStates::ANTIDRIP:
            safety.setContext(CTX_MOVING_FREE); btnSelect.update(); btnUp.update(); btnDown.update();
            if (millis() - antiDripTimer > TIME_ANTIDRIP_MAX) fsm_state.currentState = InjectorStates::READY_TO_INJECT;
            if (btnSelect.pressed()) fsm_state.currentState = InjectorStates::READY_TO_INJECT;
            if (btnUp.read() == LOW && btnDown.read() == LOW) fsm_state.currentState = InjectorStates::INJECT;
            break;
        case InjectorStates::INJECT:
            safety.setContext(CTX_BLOCKED); btnSelect.update();
            motor.setControllerMode(2, 1);
            // ADDED MOTION: Move down at Fast Speed
            rampVelocity(SPEED_FAST_MOVE, 1.0f); 
            
            if (btnSelect.pressed()) { motor.stop(); fsm_state.currentState = InjectorStates::RELEASE; }
            break;
        case InjectorStates::RELEASE: fsm_state.currentState = InjectorStates::CONFIRM_MOULD_REMOVAL; break;
        case InjectorStates::CONFIRM_MOULD_REMOVAL:
             btnSelect.update();
             if(btnSelect.pressed()) { if(flags.endOfDay) fsm_state.currentState = InjectorStates::READY_TO_INJECT; else fsm_state.currentState = InjectorStates::REFILL; }
             break;
        case InjectorStates::HOLD_INJECTION: break;
    }
    updateLeds();
    if (millis() - lastDebugTime > 1000) { lastDebugTime = millis(); printDebugReport(); }
}