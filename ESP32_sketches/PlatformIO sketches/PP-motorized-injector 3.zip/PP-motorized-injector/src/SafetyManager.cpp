#include "SafetyManager.h"
#include "CanBusHandler.h" 

extern CanBusHandler motor; 

SafetyManager::SafetyManager() : _lastError(ERR_NONE), _wasMovingDown(false), _currentContext(CTX_IDLE) {}

void SafetyManager::begin() {
    // 1. Initialize Debouncers
    dbEStop.attach(PIN_ESTOP, INPUT); 
    dbEStop.interval(DEBOUNCE_MS_SAFETY); 
    
    dbBarrel.attach(PIN_ENDSTOP_BARREL, INPUT_PULLUP);
    dbBarrel.interval(DEBOUNCE_MS_SAFETY);

    dbTop.attach(PIN_ENDSTOP_TOP, INPUT_PULLUP);
    dbTop.interval(DEBOUNCE_MS_SAFETY);

    dbBot.attach(PIN_ENDSTOP_BOTTOM, INPUT_PULLUP);
    dbBot.interval(DEBOUNCE_MS_SAFETY);

    // 2. Outputs & Sensors
    pinMode(PIN_CONTACTOR, OUTPUT);
    enableMotorPower(false);
    
    _loadCell.begin(PIN_HX711_DAT, PIN_HX711_CLK);
    _loadCell.tare(); 
}

// Call this once per loop in main.cpp
void SafetyManager::updateInputs() {
    dbEStop.update();
    dbBarrel.update();
    dbTop.update();
    dbBot.update();
    
    // Update Pressure (Non-blocking check)
    if (_loadCell.is_ready()) {
        long reading = _loadCell.read();
        // Simple Noise Filter for Pressure: Ignore -1 or huge jumps?
        // For now, just read it.
        _currentPressure = reading;
    }
}

// --- Getters (Clean Logic) ---
bool SafetyManager::isEStopPressed() { return dbEStop.read() == HIGH; }
bool SafetyManager::isBarrelOpen()   { return dbBarrel.read() == HIGH; }
bool SafetyManager::isTopEndstopHit() { return dbTop.read() == LOW; } // Inductive: LOW = Metal
bool SafetyManager::isBottomEndstopHit() { return dbBot.read() == LOW; }

void SafetyManager::enableMotorPower(bool enable) {
    if (enable && isEStopPressed()) {
        triggerHalt(ERR_ESTOP);
        return;
    }
    digitalWrite(PIN_CONTACTOR, enable ? HIGH : LOW);
}

void SafetyManager::triggerHalt(MachineError err) {
    if (_lastError != err) {
        Serial.printf("!!! SAFETY HALT: Error Code %d !!!\n", err);
        _lastError = err;
    }
    enableMotorPower(false);
}

void SafetyManager::setContext(SafetyContext ctx) {
    _currentContext = ctx;
}

bool SafetyManager::check(float current_velocity, bool is_moving_down) {
    // Note: updateInputs() is called in main loop, so we just read the state here

    if (isEStopPressed()) {
        triggerHalt(ERR_ESTOP);
        return false;
    }

    if (isBarrelOpen()) { 
        triggerHalt(ERR_BARREL_POSITION_LOST);
        return false;
    }

    // Pressure Logic (Barrel Slip Detection)
    if (is_moving_down && abs(current_velocity) > 0.1f) {
        if (!_wasMovingDown) {
            _moveStartTime = millis();
            _pressureBaseline = _currentPressure;
            _startPosition = motor.getPosition(); 
            _wasMovingDown = true;
        }

        long pressureDelta = _currentPressure - _pressureBaseline;
        float distMoved = abs(motor.getPosition() - _startPosition);

        if (_currentContext == CTX_BLOCKED) {
            if (distMoved > 10.0f && abs(pressureDelta) < PRESSURE_BLOCK_MIN) {
                 triggerHalt(ERR_NOZZLE_NOT_BLOCKED);
                 return false;
            }
        }
    } else {
        _wasMovingDown = false;
    }

    return (_lastError == ERR_NONE);
}

void SafetyManager::resetError() {
    _lastError = ERR_NONE;
}