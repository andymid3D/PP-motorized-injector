#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_NeoPixel.h>
#include <Bounce2.h>
#include <SafeString.h>

#include "config.h"
#include "injector_fsm.h"
#include "SafetyManager.h"
#include "CanBusHandler.h"

// --- FSM Global Variables ---
fsm_inputs_t fsm_inputs;
fsm_outputs_t fsm_outputs;
fsm_state_t fsm_state;

// --- Hardware Objects ---
SafetyManager safety;
CanBusHandler motor;
Adafruit_NeoPixel ledsButtons(LED_COUNT_BUTTONS, PIN_LED_BUTTONS, NEO_GRB + NEO_KHZ800);
Adafruit_NeoPixel ledsRing(LED_COUNT_RING, PIN_LED_RING, NEO_GRB + NEO_KHZ800);

// --- Input Debouncers ---
Bounce2::Button btnSelect = Bounce2::Button();
Bounce2::Button btnUp = Bounce2::Button();
Bounce2::Button btnDown = Bounce2::Button();

// --- Global Flags & Timers ---
MachineFlags flags = {0, 0, 0}; 
unsigned long lastAutoCompress = 0;
unsigned long antiDripTimer = 0;
unsigned long lastDebugTime = 0;
bool tempErrorActive = false; 

// --- Global Parameter Array ---
float constantInjectionParams[] = {
    SPEED_PURGE, SPEED_FAST_MOVE, SPEED_COMPRESS_INIT, SPEED_COMPRESS_MIN,
    (float)TIME_ANTIDRIP_MAX, SPEED_PURGE, SPEED_RELEASE, DIST_RELEASE_MOULD
};

// --- CENTRALIZED LOGGING FUNCTION ---
void logMessage(const char* msg) {
    Serial.println(msg);
}

// --- Helper: Read AD597 Analog Temp (HEAVY FILTER) ---
int readThermocouple() {
    // 1. Take a quick burst of samples
    long sum = 0;
    const int samples = 10;
    for(int i=0; i<samples; i++) {
        sum += analogRead(PIN_TEMP_ANALOG);
    }
    float avgAdc = sum / (float)samples;
    
    // 2. Convert to Celsius
    float voltage = (avgAdc / 4095.0) * 3.3;
    float currentTemp = voltage / 0.01; 

    // 3. Apply Exponential Moving Average (EMA)
    // This acts like a software capacitor.
    // "static" keeps the value in memory between loops.
    static float smoothedTemp = 0;
    
    // Initialize on first run
    if (smoothedTemp == 0) smoothedTemp = currentTemp;
    
    // Filter Math: 95% History, 5% New Reading
    // A noise spike of 0°C will only pull the reading down by a tiny fraction.
    smoothedTemp = (smoothedTemp * 0.95) + (currentTemp * 0.05);
    
    return (int)smoothedTemp;
}

// --- Helper: State to String ---
const char* getStateName(int state) {
    switch(state) {
        case ERROR_STATE: return "ERROR";
        case INIT_HEATING: return "INIT_HEATING";
        case INIT_HOT_NOT_HOMED: return "INIT_HOT_NOT_HOMED";
        case INIT_HOMING: return "INIT_HOMING";
        case REFILL: return "REFILL";
        case COMPRESSION: return "COMPRESSION";
        case READY_TO_INJECT: return "READY_TO_INJECT";
        case PURGE_ZERO: return "PURGE_ZERO";
        case ANTIDRIP: return "ANTIDRIP";
        case INJECT: return "INJECT";
        case HOLD_INJECTION: return "HOLD";
        case RELEASE: return "RELEASE";
        case CONFIRM_MOULD_REMOVAL: return "CONFIRM_REMOVAL";
        default: return "UNKNOWN";
    }
}

// --- Helper: LED Logic ---
void updateLeds() {
    uint32_t colSel = BLACK_RGB;
    uint32_t colUp = BLACK_RGB;
    uint32_t colDown = BLACK_RGB;
    uint32_t colRing = BLACK_RGB;

    switch (fsm_state.currentState) {
        case ERROR_STATE:
            if ((millis() / 500) % 2 == 0) {
                colSel = RED_RGB; colUp = RED_RGB; colDown = RED_RGB; colRing = RED_RGB;
            }
            break;
        case INIT_HEATING:
            colSel = RED_RGB; colUp = RED_RGB; colDown = RED_RGB; colRing = RED_RGB;
            break;
        case INIT_HOT_NOT_HOMED:
            colSel = YELLOW_RGB; colUp = YELLOW_RGB; colDown = YELLOW_RGB; colRing = YELLOW_RGB;
            break;
        case INIT_HOMING:
            colUp = YELLOW_RGB; colRing = YELLOW_RGB;
            break;
        case REFILL:
            colSel = GREEN_RGB; 
            if (flags.endOfDay) { colUp = BLUE_RGB; colDown = BLUE_RGB; }
            else { colUp = BLACK_RGB; colDown = BLACK_RGB; }
            colRing = GREEN_RGB;
            break;
        case COMPRESSION:
            colSel = RED_RGB; colRing = RED_RGB;
            break;
        case READY_TO_INJECT:
            colSel = GREEN_RGB; colUp = YELLOW_RGB; colDown = YELLOW_RGB; colRing = GREEN_RGB;
            break;
        case PURGE_ZERO:
            colSel = GREEN_RGB; colUp = YELLOW_RGB; colDown = YELLOW_RGB; colRing = YELLOW_RGB;
            break;
        case ANTIDRIP:
            colSel = RED_RGB; colUp = GREEN_RGB; colDown = GREEN_RGB; colRing = RED_RGB;
            break;
        case INJECT:
            colSel = RED_RGB; colUp = GREEN_RGB; colDown = BLACK_RGB; colRing = RED_RGB;
            break;
        case HOLD_INJECTION:
            colSel = RED_RGB; colUp = GREEN_RGB; colDown = GREEN_RGB; colRing = RED_RGB;
            break;
        case RELEASE:
            colSel = GREEN_RGB; colUp = GREEN_RGB; colDown = GREEN_RGB; colRing = GREEN_RGB;
            break;
        case CONFIRM_MOULD_REMOVAL:
            colSel = GREEN_RGB; colUp = GREEN_RGB; colDown = GREEN_RGB; colRing = GREEN_RGB;
            break;
    }

    ledsButtons.setPixelColor(0, colSel);
    ledsButtons.setPixelColor(1, colUp);
    ledsButtons.setPixelColor(2, colDown);
    ledsButtons.show();
    for(int i=0; i<LED_COUNT_RING; i++) ledsRing.setPixelColor(i, colRing);
    ledsRing.show();
}

// --- Homing Sequence Helper ---
bool runHomingSequence() {
    static int step = 0;
    static int lastStep = -1; 
    static unsigned long waitStart = 0;
    
    if (step != lastStep) {
        switch(step) {
            case 0: logMessage("Homing: Clearing Errors..."); break;
            case 2: logMessage("Homing: Calibrating Encoder (State 7)..."); break;
            case 5: logMessage("Homing: Enabling Closed Loop..."); break;
            case 6: logMessage("Homing: Motor ON. Retracting..."); break;
        }
        lastStep = step;
    }

    if (step >= 2 && motor.getAxisError() != 0) {
        cSF(errBuf, 64);
        errBuf.print("Homing Interrupted! Error: 0x");
        errBuf.print(motor.getAxisError(), HEX);
        logMessage(errBuf.c_str());
        step = 0; 
        return false;
    }

    switch(step) {
        case 0: // 1. Clear Errors
            safety.setContext(CTX_MOVING_FREE);
            motor.clearErrors(); 
            waitStart = millis();
            step++;
            break;

        case 1: // Wait for Clear
            if (millis() - waitStart > 500) step++;
            break;

        case 2: // 2. Request Calibration
            motor.setAxisState(7); 
            waitStart = millis();
            step++;
            break;

        case 3: // Wait for Calibration Start
            if (motor.getAxisState() == 7) step++;
            if (millis() - waitStart > 1000) step++; 
            break;

        case 4: // Wait for Calibration Finish
            if (motor.getAxisState() == 1) {
                logMessage("Homing: Calibration Done.");
                step++;
            }
            break;

        case 5: // 3. Enable Closed Loop
            if (motor.getAxisState() != 8) {
                motor.setAxisState(8); 
            } else {
                step++; 
            }
            break;
            
        case 6: // 4. Start Motion
            motor.setVelocity(-SPEED_HOMING_FAST);
            
            // USE CENTRALIZED DEBOUNCER
            if (safety.isTopEndstopHit()) { 
                motor.stop();
                step++;
            }
            break;
            
        case 7: // Back Off
            motor.setPosition(motor.getPosition() + DIST_HOME_BACKOFF);
            waitStart = millis();
            step++;
            break;
        case 8: // Wait for Move
            if (millis() - waitStart > 500) step++; 
            break;
        case 9: // Slow Retract
            motor.setVelocity(-SPEED_HOMING_SLOW);
            if (safety.isTopEndstopHit()) { 
                motor.stop();
                step++;
            }
            break;
        case 10: // Zeroing
            if (!flags.initialHomingDone) {
                motor.setPosition(0.0f); 
                flags.initialHomingDone = true;
            } else {
                float drift = motor.getPosition(); 
                cSF(driftMsg, 64);
                driftMsg.print("Homing Drift: "); driftMsg.print(drift, 4);
                logMessage(driftMsg.c_str());
            }
            logMessage("Homing: Complete.");
            step = 0; 
            lastStep = -1; 
            return true; 
    }
    return false;
}

// --- Compression Helper ---
bool runCompressionCycle() {
    safety.setContext(CTX_BLOCKED);
    motor.setAxisState(8);
    motor.setVelocity(SPEED_COMPRESS_INIT);
    
    if (motor.getTorque() > TORQUE_COMPRESSION_HOLD) {
        motor.stop();
        return true;
    }
    return false;
}

/// --- DEBUG REPORT (SafeString) ---
void printDebugReport() {
    cSF(msg, 512); 
    
    msg.print("--- SYSTEM DIAGNOSTIC ---\n");
    msg.print("State: "); msg.print(getStateName(fsm_state.currentState)); 
    msg.print(" (ID: "); msg.print(fsm_state.currentState); msg.print(")\n");
    
    msg.print("Temp: "); msg.print(fsm_inputs.nozzleTemperature); msg.print(" C\n");
    msg.print("Pressure: "); msg.print(safety.getPressure()); msg.print("\n");
    
    // INPUTS: Use SafetyManager Debounced Getters
    msg.print("E-Stop: "); 
    msg.print(safety.isEStopPressed() ? 1 : 0); 
    msg.print(" (1=STOP)\n");

    msg.print("Barrel Sw: "); 
    msg.print(safety.isBarrelOpen() ? 1 : 0); 
    msg.print(" (1=OPEN)\n");

    msg.print("Top Sw: "); 
    msg.print(safety.isTopEndstopHit() ? 1 : 0); 
    msg.print(" | Bot Sw: "); 
    msg.print(safety.isBottomEndstopHit() ? 1 : 0); 
    msg.print(" (1=HIT)\n");
    
    // OUTPUTS
    msg.print("Contactor: "); 
    msg.print(digitalRead(PIN_CONTACTOR) ? "ON" : "OFF"); 
    msg.print("\n");
    
    // MOTOR / CAN
    bool isAlive = motor.isAlive();
    msg.print("CAN: "); 
    if (isAlive) {
        msg.print("ALIVE\n");
        msg.print("ODrive State: "); msg.print(motor.getAxisState()); 
        msg.print(" | Error: 0x"); msg.print(motor.getAxisError(), HEX); msg.print("\n");
    } else {
        msg.print("DEAD\n");
        msg.print("ODrive State: -- | Error: --\n");
    }
    
    msg.print("Pos: "); msg.print(motor.getPosition(), 2);
    msg.print(" | Vel: "); msg.print(motor.getVelocity(), 2);
    msg.print("\n-------------------------");
    
    Serial.println(msg);
}

void setup() {
    Serial.begin(115200);
    delay(1000);
    SafeString::setOutput(Serial); 
    
    safety.begin();
    motor.begin();
    pinMode(PIN_TEMP_ANALOG, INPUT);

    ledsButtons.begin();
    ledsRing.begin();
    ledsButtons.setBrightness(LED_BRIGHT_LOW);
    ledsRing.setBrightness(LED_BRIGHT_LOW);
    
    btnSelect.attach(PIN_BTN_SELECT, INPUT_PULLUP);
    btnUp.attach(PIN_BTN_UP, INPUT_PULLUP);
    btnDown.attach(PIN_BTN_DOWN, INPUT_PULLUP);
    
    btnSelect.interval(10);
    btnUp.interval(10);
    btnDown.interval(10);
    
    fsm_state.currentState = InjectorStates::INIT_HEATING;
}

void loop() {
    motor.loop();
    safety.updateInputs();
    fsm_inputs.nozzleTemperature = readThermocouple();

    // --- 1. CRITICAL TEMP CHECK (With 1s Timer) ---
    // SAFETY: We ignore temp drops during HOMING because motor noise corrupts the sensor.
    // Plastic thermal mass guarantees it won't freeze in <10 seconds.
    static unsigned long lowTempStart = 0;
    
     if (fsm_state.currentState != INIT_HOMING) { 
        
        if (fsm_inputs.nozzleTemperature < TEMP_CRITICAL) {
             if (lowTempStart == 0) lowTempStart = millis();
             
             if (millis() - lowTempStart > 1000) {
                 if (!tempErrorActive) {
                     safety.triggerHalt(ERR_UNDER_TEMP);
                     fsm_state.currentState = InjectorStates::ERROR_STATE;
                     tempErrorActive = true; 
                 }
             }
        } 
        else { 
            lowTempStart = 0; 
            if (fsm_inputs.nozzleTemperature > (TEMP_CRITICAL + 2)) { 
                tempErrorActive = false; 
            }
        }
    } else {
        // While Homing, keep timers reset so we don't trigger immediately after
        lowTempStart = 0;
    }

    // --- 2. STANDARD SAFETY CHECK ---
    bool movingDown = motor.getVelocity() > 0.1f;
    if (!safety.check(motor.getVelocity(), movingDown)) {
        fsm_state.currentState = InjectorStates::ERROR_STATE;
        fsm_state.error = safety.getLastError();
    }

    // --- 3. STATE MACHINE ---
    switch (fsm_state.currentState) {
        case InjectorStates::ERROR_STATE:
            safety.enableMotorPower(false);
            if (digitalRead(PIN_ESTOP) == LOW && 
                digitalRead(PIN_ENDSTOP_BARREL) == LOW &&
                fsm_inputs.nozzleTemperature >= (TEMP_CRITICAL + 2)) {
                 
                 logMessage("Safety Restored.");
                 safety.resetError();
                 fsm_state.error = 0;
                 fsm_state.currentState = InjectorStates::INIT_HEATING;
            }
            break;

        case InjectorStates::INIT_HEATING:
            safety.enableMotorPower(false);
            if (fsm_inputs.nozzleTemperature >= TEMP_MIN_MOVE) {
                fsm_state.currentState = InjectorStates::INIT_HOT_NOT_HOMED;
            }
            break;

        case InjectorStates::INIT_HOT_NOT_HOMED:
            safety.enableMotorPower(true);
            btnUp.update();
            if (btnUp.pressed()) {
                fsm_state.currentState = InjectorStates::INIT_HOMING;
            }
            break;

        case InjectorStates::INIT_HOMING:
            if (runHomingSequence()) {
                motor.setPosition(OFFSET_REFILL_GAP);
                fsm_state.currentState = InjectorStates::REFILL;
            }
            break;

        // ... (Rest of cases REFILL, COMPRESSION, etc. remain identical) ...
        // Copy them from previous code or keep existing
        case InjectorStates::REFILL:
            safety.setContext(CTX_IDLE);
            btnSelect.update();
            btnUp.update();
            btnDown.update();
            if (btnUp.read() == LOW && btnDown.read() == LOW) {
                flags.endOfDay = !flags.endOfDay;
                delay(500); 
            }
            if (btnSelect.pressed()) fsm_state.currentState = InjectorStates::COMPRESSION;
            break;

        case InjectorStates::COMPRESSION:
            btnSelect.update();
            if (btnSelect.pressed()) { motor.stop(); fsm_state.currentState = InjectorStates::REFILL; }
            if (runCompressionCycle()) { fsm_state.currentState = InjectorStates::READY_TO_INJECT; lastAutoCompress = millis(); }
            break;

        case InjectorStates::READY_TO_INJECT:
            safety.setContext(CTX_IDLE);
            btnSelect.update(); btnUp.update(); btnDown.update();
            if (millis() - lastAutoCompress > TIME_AUTO_COMPRESS) fsm_state.currentState = InjectorStates::COMPRESSION; 
            if (btnUp.pressed()) fsm_state.currentState = InjectorStates::REFILL;
            if (btnSelect.read() == LOW && btnDown.read() == LOW) fsm_state.currentState = InjectorStates::PURGE_ZERO;
            break;

        case InjectorStates::PURGE_ZERO:
            safety.setContext(CTX_PURGE);
            btnUp.update(); btnDown.update(); btnSelect.update();
            if (btnUp.isPressed()) motor.setVelocity(-SPEED_PURGE);
            else if (btnDown.isPressed()) motor.setVelocity(SPEED_PURGE);
            else motor.stop();
            if (btnSelect.pressed()) {
                fsm_state.currentState = InjectorStates::ANTIDRIP;
                antiDripTimer = millis();
                motor.setPosition(motor.getPosition() + DIST_ANTIDRIP_REV);
            }
            break;

        case InjectorStates::ANTIDRIP:
            safety.setContext(CTX_MOVING_FREE);
            btnSelect.update(); btnUp.update(); btnDown.update();
            if (millis() - antiDripTimer > TIME_ANTIDRIP_MAX) fsm_state.currentState = InjectorStates::READY_TO_INJECT;
            if (btnSelect.pressed()) fsm_state.currentState = InjectorStates::READY_TO_INJECT;
            if (btnUp.read() == LOW && btnDown.read() == LOW) fsm_state.currentState = InjectorStates::INJECT;
            break;

        case InjectorStates::INJECT:
            safety.setContext(CTX_BLOCKED);
            btnSelect.update();
            if (btnSelect.pressed()) { motor.stop(); fsm_state.currentState = InjectorStates::RELEASE; }
            break;
            
        case InjectorStates::RELEASE:
             fsm_state.currentState = InjectorStates::CONFIRM_MOULD_REMOVAL;
             break;
             
        case InjectorStates::CONFIRM_MOULD_REMOVAL:
             btnSelect.update();
             if(btnSelect.pressed()) {
                 if(flags.endOfDay) fsm_state.currentState = InjectorStates::READY_TO_INJECT;
                 else fsm_state.currentState = InjectorStates::REFILL;
             }
             break;
             
        case InjectorStates::HOLD_INJECTION:
             break;
    }
    
    updateLeds();

    if (millis() - lastDebugTime > 500) {
        lastDebugTime = millis();
        printDebugReport();
    }
}