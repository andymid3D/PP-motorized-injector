#include "CanBusHandler.h"
#include <ESP32-TWAI-CAN.hpp> // Explicit include for the library


CanBusHandler::CanBusHandler() : _currentPos(0), _currentVel(0), _lastHeartbeat(0) {}

void CanBusHandler::begin() {
    // Setup ESP32 TWAI (CAN)
    // TX=21, RX=22
    ESP32Can.setPins(PIN_CAN_TX, PIN_CAN_RX);
    ESP32Can.setSpeed(TWAI_SPEED_250KBPS); // ODrive Default
    ESP32Can.begin();
}

void CanBusHandler::loop() {
    CanFrame rxFrame;
    if (ESP32Can.readFrame(rxFrame, 0)) { 
        // 1. Extract Node ID
        uint32_t nodeId = rxFrame.identifier >> 5;
        uint32_t cmdId = rxFrame.identifier & 0x01F; 
        
        // 2. FILTER: Ignore messages from other axes (like Axis 1)
        if (nodeId != ODRIVE_NODE_ID) return; 

        if (cmdId == CMD_HEARTBEAT) {
            _lastHeartbeat = millis();
            memcpy(&_axisError, &rxFrame.data[0], 4);
            memcpy(&_axisState, &rxFrame.data[4], 1); // Read 1 byte
        }
        else if (cmdId == CMD_GET_ENCODER) {
            memcpy(&_currentPos, &rxFrame.data[0], 4);
            memcpy(&_currentVel, &rxFrame.data[4], 4);
        }
        else if (cmdId == CMD_GET_TORQUES) {
            memcpy(&_currentTorque, &rxFrame.data[0], 4);
        }
    }
}

void CanBusHandler::sendFloat(uint32_t id, float value) {
    CanFrame frame;
    frame.identifier = (ODRIVE_NODE_ID << 5) | id;
    frame.extd = 0;
    frame.data_length_code = 8;
    memcpy(&frame.data[0], &value, 4);
    // Padding
    frame.data[4] = 0; frame.data[5] = 0; frame.data[6] = 0; frame.data[7] = 0;
    ESP32Can.writeFrame(frame);
}

void CanBusHandler::sendCommand(uint32_t id, uint32_t value) {
    CanFrame frame;
    frame.identifier = (ODRIVE_NODE_ID << 5) | id;
    frame.extd = 0;
    frame.data_length_code = 8; // ODrive expects 8 bytes usually, even if using less
    memcpy(&frame.data[0], &value, 4);
    ESP32Can.writeFrame(frame);
}

void CanBusHandler::setAxisState(uint32_t state) {
    sendCommand(CMD_SET_AXIS_STATE, state);
}

void CanBusHandler::setVelocity(float turns_per_sec) {
    // Safety Clamp
    if (turns_per_sec > VEL_LIMIT_INJECT) turns_per_sec = VEL_LIMIT_INJECT;
    if (turns_per_sec < -VEL_LIMIT_INJECT) turns_per_sec = -VEL_LIMIT_INJECT;
    
    // ODrive Input Vel
    // Note: You also need to send Input Torque FF (0.0f) usually
    CanFrame frame;
    frame.identifier = (ODRIVE_NODE_ID << 5) | CMD_SET_INPUT_VEL;
    frame.extd = 0;
    frame.data_length_code = 8;
    memcpy(&frame.data[0], &turns_per_sec, 4);
    float torque_ff = 0.0f;
    memcpy(&frame.data[4], &torque_ff, 4);
    ESP32Can.writeFrame(frame);
}

void CanBusHandler::setPosition(float turns) {
    // Safety Clamp
    if (turns > POS_BOTTOM_MAX) turns = POS_BOTTOM_MAX;
    if (turns < POS_HOME) turns = POS_HOME;

    // ODrive Input Pos
    CanFrame frame;
    frame.identifier = (ODRIVE_NODE_ID << 5) | CMD_SET_INPUT_POS;
    frame.extd = 0;
    frame.data_length_code = 8;
    memcpy(&frame.data[0], &turns, 4);
    // Vel FF and Torque FF (0, 0)
    int16_t vel_ff = 0;
    int16_t torque_ff = 0;
    memcpy(&frame.data[4], &vel_ff, 2);
    memcpy(&frame.data[6], &torque_ff, 2);
    ESP32Can.writeFrame(frame);
}

void CanBusHandler::setTorque(float torque_nm) {
    // Safety Clamp (User defined Hard Limit)
    // Note: ODrive usually takes Torque in Nm. 
    // Ensure CURRENT_LIMIT_HARD in config.h is converted if needed, 
    // but usually we limit Current in ODrive config, and request Torque here.
    
    CanFrame frame;
    frame.identifier = (ODRIVE_NODE_ID << 5) | 0x00E; // CMD_SET_INPUT_TORQUE
    frame.extd = 0;
    frame.data_length_code = 8;
    memcpy(&frame.data[0], &torque_nm, 4);
    ESP32Can.writeFrame(frame);
}


void CanBusHandler::stop() {
    setVelocity(0.0f);
}

void CanBusHandler::clearErrors() {
    // ODrive Command: Clear Errors (0x018)
    sendCommand(0x018, 0);
}