#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

// ==========================================
// 1. PIN DEFINITIONS (HAL)
// ==========================================

// --- Motion Control (ODrive CANbus) ---
// RIGHT SIDE PINS (Neighbors)
#define PIN_CAN_RX              22  // was 22
#define PIN_CAN_TX              23  // was 23

// --- Power Control ---
// LEFT SIDE PIN (Near MOSFET)
#define PIN_CONTACTOR           13  // MOSFET Gate

// --- Safety Inputs (Right Side) ---
#define PIN_ESTOP               21   
#define PIN_ENDSTOP_TOP         19  
#define PIN_ENDSTOP_BOTTOM      18  
#define PIN_ENDSTOP_BARREL      5   

// --- Sensors ---
// Thermocouple (AD597 - Analog) - LEFT SIDE
// 10mV per Degree C. 
#define PIN_TEMP_ANALOG         36  // VP Pin

// Pressure (HX711) - RIGHT SIDE
// POWER NOTE: Connect HX711 VCC to 3.3V!
#define PIN_HX711_DAT           15
#define PIN_HX711_CLK           4

// --- User Interface ---
// UART (Right Side)
#define PIN_UART_TX             17
#define PIN_UART_RX             16

// Buttons (Left Side)
#define PIN_BTN_SELECT          25
#define PIN_BTN_UP              26
#define PIN_BTN_DOWN            27

// LEDs (Left Side)
#define PIN_LED_RING            32
#define PIN_LED_BUTTONS         33

// ==========================================
// 2. LED CONFIGURATION
// ==========================================
#define LED_COUNT_RING          35
#define LED_COUNT_BUTTONS       3

// Colors (GRB Format)
#define GREEN_RGB               0x008000
#define RED_RGB                 0xFF0000
#define YELLOW_RGB              0xFF8C00
#define BLUE_RGB                0x0000FF
#define BLACK_RGB               0x000000
#define WHITE_RGB               0xFFFFFF

#define LED_BRIGHT_LOW          50
#define LED_BRIGHT_HIGH         200

// ==========================================
// 3. MECHANICAL CONSTANTS (ODrive Units)
// ==========================================

// Ratio: 1 Turn ≈ 1 cm3 Volume
#define TURNS_PER_CM_LINEAR     5.305f
#define TURNS_PER_CM3_VOL       0.99925f 

// Absolute Positions (Turns, 0 = Top Home)
#define POS_HOME                0.0f
#define OFFSET_REFILL_GAP       47.746f 
#define OFFSET_COLD_ZONE        42.441f 
#define POS_HEATED_ZONE_START   (OFFSET_REFILL_GAP + OFFSET_COLD_ZONE) // ~90.187
#define STROKE_HEATED_ZONE      265.25f 
#define POS_BOTTOM_MAX          (POS_HEATED_ZONE_START + STROKE_HEATED_ZONE) // ~355.4

// ==========================================
// 4. PROCESS VARIABLES (Converted to Turns/Sec)
// ==========================================

// ODrive Configuration
#define ODRIVE_NODE_ID          0      // <--- WAS MISSING
#define VEL_LIMIT_INJECT        25.0f  // <--- WAS MISSING (Max physical speed)


// Speeds (Turns/Sec)
#define SPEED_PURGE             1.0f   
#define SPEED_FAST_MOVE         25.0f  // Max Speed
#define SPEED_HOMING_FAST       12.5f  
#define SPEED_HOMING_SLOW       2.5f   
#define SPEED_COMPRESS_INIT     12.5f  
#define SPEED_COMPRESS_MIN      1.0f   
#define SPEED_RELEASE           25.0f  

// Distances (Turns)
#define DIST_HOME_BACKOFF       2.65f  // ~5mm 
#define DIST_RELEASE_MOULD      -2.5f  // ~5mm up 
#define DIST_ANTIDRIP_REV       -5.3f  // ~1cm up 

// Torque / Pressure 
#define TORQUE_COMPRESSION_HOLD 5.0f   // Amps/Nm (To be calibrated)
#define PRESSURE_BLOCK_MIN      50000  // HX711 Raw Threshold

// Timing & Temp
#define TIME_ANTIDRIP_MAX       15000  // ms
#define TIME_AUTO_COMPRESS      30000  // ms 
#define TEMP_MIN_MOVE           16     // ºC
#define TEMP_CRITICAL           13     // (Testing value - 3 degrees lower)
#define DEBOUNCE_MS_SAFETY      150

// Odesc CAN node ID
#define ODRIVE_NODE_ID          0



// ==========================================
// 5. DATA STRUCTURES (For Display/UART)
// ==========================================

// Global Flags (Used in main.cpp)
struct MachineFlags {                  // 
    bool endOfDay;           
    bool initialHomingDone;
    bool barrelHeated;
};

// Struct for specific Mould Parameters (Sent from Display)
struct ActualMouldParams {
    char mouldName[20];      // Name
    float fillSpeed;         // Turns/sec
    float fillVolume;        // Turns (cm3)
    float fillPressureMax;   // Torque Limit
    float holdSpeed;         // Turns/sec
    float holdVolume;        // Turns (cm3)
    float holdPressure;      // Torque Limit
    int coolingTimeSec;      // Seconds
};

// Array of Common Parameters (Sent to Display for editing)
// EXTERN DECLARATION ONLY (Fixes Multiple Definition Error)
extern float constantInjectionParams[]; 

#endif // CONFIG_H