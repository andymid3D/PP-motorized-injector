#ifndef SAFETY_MANAGER_H
#define SAFETY_MANAGER_H

#include <Arduino.h>
#include <Bounce2.h> // Centralized Include
#include "config.h"
#include "HX711.h"

enum MachineError {
    ERR_NONE = 0,
    ERR_ESTOP = 1,
    ERR_BARREL_POSITION_LOST = 2, 
    ERR_NOZZLE_NOT_BLOCKED = 3,   
    ERR_OVER_TEMP = 4,
    ERR_HARD_LIMIT = 5,
    ERR_UNDER_TEMP = 6
};

enum SafetyContext {
    CTX_IDLE,
    CTX_MOVING_FREE,    
    CTX_BLOCKED,        
    CTX_PURGE           
};

class SafetyManager {
public:
    SafetyManager();
    void begin();
    
    // Main Loop Functions
    void updateInputs(); // Call this at start of loop()
    bool check(float current_velocity, bool is_moving_down);
    
    // Context & Control
    void setContext(SafetyContext ctx);
    void enableMotorPower(bool enable);
    void triggerHalt(MachineError err);
    void resetError();
    
    // Clean Getters (Use these in main.cpp instead of digitalRead)
    bool isEStopPressed();      // Returns true if STOP
    bool isBarrelOpen();        // Returns true if OPEN/SLIP
    bool isTopEndstopHit();     // Returns true if HIT (Metal Detected)
    bool isBottomEndstopHit();  // Returns true if HIT (Metal Detected)
    
    MachineError getLastError() { return _lastError; }
    long getPressure() { return _currentPressure; }

private:
    HX711 _loadCell;
    MachineError _lastError;
    SafetyContext _currentContext; 
    
    long _currentPressure;
    long _pressureBaseline;
    unsigned long _moveStartTime;
    bool _wasMovingDown;
    float _startPosition; 

    // Centralized Debouncers
    Bounce2::Button dbEStop = Bounce2::Button();
    Bounce2::Button dbBarrel = Bounce2::Button();
    Bounce2::Button dbTop = Bounce2::Button();
    Bounce2::Button dbBot = Bounce2::Button();
};

#endif